import * as React from "react";

export interface AddinControlsProps {
    id: string;
    serviceUrl: string;
    controlUrl:string
    visibility: string[];
  }

export default class AddinControls extends React.Component<AddinControlsProps> {


}
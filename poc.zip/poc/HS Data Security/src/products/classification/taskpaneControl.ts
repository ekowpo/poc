// eslint-disable-next-line no-undef
Office.onReady((info) => {
  // eslint-disable-next-line no-undef
  if (info.host === Office.HostType.Outlook) {
    // eslint-disable-next-line no-undef
    document.getElementById("Apply").onclick = run;
  }
});

export async function run() {
  // eslint-disable-next-line no-undef
  let classification: HTMLSelectElement = document.getElementById("Classification") as HTMLSelectElement;
  const selectedValue = classification.value;
  // eslint-disable-next-line no-undef
  Office.context.mailbox.item.internetHeaders.setAsync({ "x-hs-customheaders": selectedValue }, function (asyncResult) {
    // eslint-disable-next-line no-undef
    if (asyncResult.status === Office.AsyncResultStatus.Succeeded) {
      // eslint-disable-next-line no-undef
      console.log("Successfully set headers");
    } else {
      // eslint-disable-next-line no-undef
      console.log("Error setting headers: " + JSON.stringify(asyncResult.error));
    }
  });
}
